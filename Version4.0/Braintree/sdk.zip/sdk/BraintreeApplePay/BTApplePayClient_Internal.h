#import "BTApplePayClient.h"

@interface BTApplePayClient ()
/*!
 @brief Exposed for testing to get the instance of BTAPIClient
*/
@property (nonatomic, strong) BTAPIClient *apiClient;

@end
