#import "BTThreeDSecureErrors.h"

NSString * const BTThreeDSecureErrorDomain = @"com.braintreepayments.BTThreeDSecureErrorDomain";
NSString * const BTThreeDSecureInfoKey = @"com.braintreepayments.BTThreeDSecureInfoKey";
NSString * const BTThreeDSecureValidationErrorsKey = @"com.braintreepayments.BTThreeDSecureValidationErrorsKey";
