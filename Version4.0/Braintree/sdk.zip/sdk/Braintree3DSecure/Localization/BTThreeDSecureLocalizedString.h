#import <Foundation/Foundation.h>

#define BTThreeDSecureLocalizedString(KEY) [BTThreeDSecureLocalizedString KEY]

@interface BTThreeDSecureLocalizedString : NSObject

+ (NSString *)ERROR_ALERT_OK_BUTTON_TEXT;
+ (NSString *)ERROR_ALERT_CANCEL_BUTTON_TEXT;

@end
