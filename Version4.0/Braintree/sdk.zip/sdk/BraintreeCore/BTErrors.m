#import "BTErrors.h"

#pragma mark Error userInfo Keys

NSString *const BTCustomerInputBraintreeValidationErrorsKey = @"BTCustomerInputBraintreeValidationErrorsKey";
