#import <Foundation/Foundation.h>

#pragma mark NSError userInfo Keys

/*!
 @brief NSError userInfo key for validation errors.
*/
extern NSString * _Nonnull const BTCustomerInputBraintreeValidationErrorsKey;
