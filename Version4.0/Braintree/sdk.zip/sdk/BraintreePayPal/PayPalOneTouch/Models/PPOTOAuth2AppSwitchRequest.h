//
//  PPOTOAuth2AppSwitchRequest.h
//  PayPalOneTouch
//
//  Copyright © 2015 PayPal, Inc. All rights reserved.
//

#import "PPOTOAuth2SwitchRequest.h"

@interface PPOTOAuth2AppSwitchRequest : PPOTOAuth2SwitchRequest

@end
