#import <UIKit/UIKit.h>

@class BTUI;

@interface BTUICoinbaseButton : UIControl

@property (nonatomic, strong) BTUI *theme;

@end
