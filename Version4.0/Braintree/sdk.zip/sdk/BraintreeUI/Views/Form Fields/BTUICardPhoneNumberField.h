#import "BTUIFormField.h"

@interface BTUICardPhoneNumberField : BTUIFormField

@property (nonatomic, copy) NSString *phoneNumber;

@end
