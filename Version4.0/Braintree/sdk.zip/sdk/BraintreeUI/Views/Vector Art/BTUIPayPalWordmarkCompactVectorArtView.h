#import "BTUIPayPalWordmarkVectorArtView.h"

@interface BTUIPayPalWordmarkCompactVectorArtView : BTUIPayPalWordmarkVectorArtView

@end
