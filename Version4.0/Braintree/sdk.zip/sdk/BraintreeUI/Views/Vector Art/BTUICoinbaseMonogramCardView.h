#import "BTUICardVectorArtView.h"

@interface BTUICoinbaseMonogramCardView : BTUICardVectorArtView

@end
