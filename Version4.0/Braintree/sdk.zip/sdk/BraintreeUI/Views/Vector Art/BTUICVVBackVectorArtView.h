#import "BTUICardVectorArtView.h"

@interface BTUICVVBackVectorArtView : BTUICardVectorArtView

@end
