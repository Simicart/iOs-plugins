#import "BTUICardVectorArtView.h"

@interface BTUICVVFrontVectorArtView : BTUICardVectorArtView

@end
