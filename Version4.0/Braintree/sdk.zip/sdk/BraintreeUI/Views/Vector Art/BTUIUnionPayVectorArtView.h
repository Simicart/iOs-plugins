#import "BTUICardVectorArtView.h"

@interface BTUIUnionPayVectorArtView : BTUICardVectorArtView

@end
