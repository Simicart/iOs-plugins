#import "BTUIKCardVectorArtView.h"

@interface BTUIKApplePayMarkVectorArtView : BTUIKCardVectorArtView

@end
