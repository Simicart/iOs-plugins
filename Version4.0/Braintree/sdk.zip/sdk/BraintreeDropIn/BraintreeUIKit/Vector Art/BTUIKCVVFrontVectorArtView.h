#import "BTUIKCardVectorArtView.h"

@interface BTUIKCVVFrontVectorArtView : BTUIKCardVectorArtView

@end
