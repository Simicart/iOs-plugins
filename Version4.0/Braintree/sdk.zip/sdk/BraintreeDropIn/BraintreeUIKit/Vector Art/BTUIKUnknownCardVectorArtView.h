#import "BTUIKCardVectorArtView.h"

@interface BTUIKUnknownCardVectorArtView : BTUIKCardVectorArtView

@end
