#import "BTUIKCardVectorArtView.h"

@interface BTUIKDinersClubVectorArtView : BTUIKCardVectorArtView

@end
