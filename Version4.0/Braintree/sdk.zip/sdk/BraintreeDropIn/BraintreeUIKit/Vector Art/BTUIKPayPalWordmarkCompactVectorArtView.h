#import "BTUIKPayPalWordmarkVectorArtView.h"

@interface BTUIKPayPalWordmarkCompactVectorArtView : BTUIKPayPalWordmarkVectorArtView

@end
