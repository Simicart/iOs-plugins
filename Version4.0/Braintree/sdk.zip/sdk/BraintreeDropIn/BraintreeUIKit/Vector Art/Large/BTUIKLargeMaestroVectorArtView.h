#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeMaestroVectorArtView : BTUIKLargeVectorArtView

@end
