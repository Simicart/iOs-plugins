#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeCoinbaseMonogramCardView : BTUIKLargeVectorArtView

@end
