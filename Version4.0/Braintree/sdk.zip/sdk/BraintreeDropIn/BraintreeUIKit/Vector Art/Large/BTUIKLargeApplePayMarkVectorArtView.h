#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeApplePayMarkVectorArtView : BTUIKLargeVectorArtView

@end
