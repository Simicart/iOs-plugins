#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeUnionPayVectorArtView : BTUIKLargeVectorArtView

@end
