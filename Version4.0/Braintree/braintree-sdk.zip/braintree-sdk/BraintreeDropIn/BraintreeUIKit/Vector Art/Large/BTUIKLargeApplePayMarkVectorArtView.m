#import "BTUIKLargeApplePayMarkVectorArtView.h"

@implementation BTUIKLargeApplePayMarkVectorArtView

- (void)drawArt {
    
}

@end
