#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargePayPalMonogramCardView : BTUIKLargeVectorArtView

@end
