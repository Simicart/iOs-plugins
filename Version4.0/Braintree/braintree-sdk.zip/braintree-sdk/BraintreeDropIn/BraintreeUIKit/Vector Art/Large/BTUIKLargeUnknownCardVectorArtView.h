#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeUnknownCardVectorArtView : BTUIKLargeVectorArtView

@end
