#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeAmExVectorArtView : BTUIKLargeVectorArtView

@end
