#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeJCBVectorArtView : BTUIKLargeVectorArtView

@end
