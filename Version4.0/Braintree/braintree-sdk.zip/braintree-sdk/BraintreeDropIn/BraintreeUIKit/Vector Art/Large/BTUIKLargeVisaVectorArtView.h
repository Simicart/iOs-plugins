#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeVisaVectorArtView : BTUIKLargeVectorArtView

@end
