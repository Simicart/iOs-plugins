#import "BTUIKVectorArtView.h"

@interface BTUIKLargeVectorArtView : BTUIKVectorArtView

@end
