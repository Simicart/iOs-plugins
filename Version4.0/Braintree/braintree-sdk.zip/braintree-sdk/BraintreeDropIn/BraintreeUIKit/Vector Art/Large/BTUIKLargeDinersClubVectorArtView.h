#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeDinersClubVectorArtView : BTUIKLargeVectorArtView

@end
