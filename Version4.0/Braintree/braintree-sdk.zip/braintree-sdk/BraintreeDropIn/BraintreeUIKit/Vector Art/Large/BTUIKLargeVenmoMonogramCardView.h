#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeVenmoMonogramCardView : BTUIKLargeVectorArtView

@end
