#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeDiscoverVectorArtView : BTUIKLargeVectorArtView

@end
