#import "BTUIKLargeVectorArtView.h"

@interface BTUIKLargeMasterCardVectorArtView : BTUIKLargeVectorArtView

@end
