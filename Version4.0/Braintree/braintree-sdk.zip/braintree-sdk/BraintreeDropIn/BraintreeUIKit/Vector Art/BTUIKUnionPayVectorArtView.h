#import "BTUIKCardVectorArtView.h"

@interface BTUIKUnionPayVectorArtView : BTUIKCardVectorArtView

@end
