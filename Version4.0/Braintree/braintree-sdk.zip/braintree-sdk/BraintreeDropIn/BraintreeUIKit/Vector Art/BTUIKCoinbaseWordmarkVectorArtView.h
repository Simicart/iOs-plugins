#import "BTUIKVectorArtView.h"

@interface BTUIKCoinbaseWordmarkVectorArtView : BTUIKVectorArtView

@property (nonatomic, strong) UIColor *color;

@end
