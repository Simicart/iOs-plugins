#import "BTUIKVectorArtView.h"

@interface BTUIKVenmoWordmarkVectorArtView : BTUIKVectorArtView

@property (nonatomic, strong) UIColor *color;

@end
