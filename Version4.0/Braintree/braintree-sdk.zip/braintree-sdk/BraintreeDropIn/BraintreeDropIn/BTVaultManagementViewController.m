#import "BTVaultManagementViewController.h"
#import "BTDropInController.h"

@interface BTVaultManagementViewController ()

@end

@implementation BTVaultManagementViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.translatesAutoresizingMaskIntoConstraints = NO;
}

@end
