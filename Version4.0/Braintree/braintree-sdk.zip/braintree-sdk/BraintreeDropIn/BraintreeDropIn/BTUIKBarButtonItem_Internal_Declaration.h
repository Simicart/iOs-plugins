#import <UIKit/UIKit.h>

@interface BTUIKBarButtonItem : UIBarButtonItem
@property (nonatomic) BOOL bold;
@end
