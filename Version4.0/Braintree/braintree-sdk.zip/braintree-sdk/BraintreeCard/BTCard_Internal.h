#import "BTCard.h"
#import "BTJSON.h"

@interface BTCard ()

- (NSDictionary *)parameters;

@end
