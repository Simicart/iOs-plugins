//
//  PayPalOneTouch.h
//  PayPalOneTouch
//
//

#import <UIKit/UIKit.h>

//! Project version number for PayPalOneTouch.
FOUNDATION_EXPORT double PayPalOneTouchVersionNumber;

//! Project version string for PayPalOneTouch.
FOUNDATION_EXPORT const unsigned char PayPalOneTouchVersionString[];

#include "PPOTCore.h"
#include "PPOTResult.h"
#include "PPOTRequest.h"
#include "PPOTRequestFactory.h"
