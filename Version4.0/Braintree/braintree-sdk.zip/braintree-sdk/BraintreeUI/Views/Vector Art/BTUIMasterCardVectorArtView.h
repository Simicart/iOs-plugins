#import "BTUICardVectorArtView.h"

@interface BTUIMasterCardVectorArtView : BTUICardVectorArtView

@end
