#import "BTUICardVectorArtView.h"

@interface BTUIDiscoverVectorArtView : BTUICardVectorArtView

@end
