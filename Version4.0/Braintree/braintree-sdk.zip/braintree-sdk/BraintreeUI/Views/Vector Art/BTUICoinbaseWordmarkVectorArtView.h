#import "BTUIVectorArtView.h"

@interface BTUICoinbaseWordmarkVectorArtView : BTUIVectorArtView

@property (nonatomic, strong) UIColor *color;

@end
