#import <UIKit/UIKit.h>

@interface BTUIPaymentButtonCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIControl *paymentButton;
@end
