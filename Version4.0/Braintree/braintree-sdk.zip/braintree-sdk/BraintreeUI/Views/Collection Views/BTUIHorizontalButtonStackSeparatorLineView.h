#import <UIKit/UIKit.h>

#import "BTUI.h"

@interface BTUIHorizontalButtonStackSeparatorLineView : UICollectionReusableView
@property (nonatomic, strong) BTUI *theme;
@end
