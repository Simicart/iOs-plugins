#import <UIKit/UIKit.h>

@interface BTUIHorizontalButtonStackCollectionViewFlowLayout : UICollectionViewFlowLayout

@end
