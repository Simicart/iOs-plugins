//
//  FirebaseAppIndexing.h
//
//  Copyright 2015 Google Inc.
//

#import "FIRAppIndexing.h"
