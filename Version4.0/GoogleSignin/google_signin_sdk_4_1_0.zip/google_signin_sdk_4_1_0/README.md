# Google Sign-In SDK for iOS

The Google Sign-In SDK allows users to sign in with their Google account from
third-party apps.

Please visit [our developer
site](https://developers.google.com/identity/sign-in/ios/) for integration
instructions, documentation, support information, and terms of service.
